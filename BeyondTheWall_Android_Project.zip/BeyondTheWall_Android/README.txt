BEYOND THE WALL - ANDROID PROJECT

This is an Android Studio project wrapping the supplied HTML game in a fullscreen WebView.
It is not an APK yet. Build it with Android Studio (JDK 17, Android SDK 35) or use the included GitHub Actions workflow.

Build command:
  gradle assembleDebug

APK output:
  app/build/outputs/apk/debug/app-debug.apk

The game currently loads Three.js from its CDN, so an internet connection is required when playing.
